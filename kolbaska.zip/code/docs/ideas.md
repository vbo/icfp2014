We need operators:
- If () else ()
- foreach
- Одномерный массив
- функции
- присваивание
- проверка (==)

Now we have:
- Closure
- Int
- List of 2 elems






Linked list with END flag. Implements as a pair, where first element (CAR) - is an item value, and second element is either
0 (means end of the list) or pair with the same properties.

Empty list: 0
One-elem list (value = 42): (42, 0)
Three-elem list (42, 17, 20): (42, (17, (20, 0)))

