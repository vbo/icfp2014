function main(world, undocumented) {
    var step = function (last_ai_state, world) {
        return [new_ai_state, move]
    }
    var ai_state = {};
    return [ai_state, step];
}
