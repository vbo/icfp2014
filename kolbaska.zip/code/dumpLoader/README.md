dumpLoader
===

file.in - stores the data to load in RAM
    (((0, (0, (0, 0))), ((0, (5, (0, 0))), ((0, (0, (0, 0))), 0))), ((0, ((1, 1), (2, (3, 0)))), (0, 0)))
file.out - results of service's job
    LDC 0
    LDC 0
    LDC 0
    LDC 0
    CONS
    CONS
    CONS

To run: perl dumplLoader.pl
